package com.cjhxfund.foundation.log.impl;

public interface Log {

	public abstract boolean isDebugEnabled();

	public abstract void error(String paramString, Throwable paramThrowable);

	public abstract void error(String paramString);

	public abstract boolean isInfoEnabled();

	public abstract void info(String paramString);

	public abstract void debug(String paramString);

	public abstract void debug(String paramString, Throwable paramThrowable);

	public abstract boolean isWarnEnabled();

	public abstract void warn(String paramString);

	public abstract void warn(String paramString, Throwable paramThrowable);

	public abstract int getErrorCount();

	public abstract int getWarnCount();

	public abstract int getInfoCount();

	public abstract int getDebugCount();

	public abstract void resetStat();
	
	
}

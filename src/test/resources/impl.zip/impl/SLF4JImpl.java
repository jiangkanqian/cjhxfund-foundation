package com.cjhxfund.foundation.log.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.spi.LocationAwareLogger;

public class SLF4JImpl implements Log {

	private static final String callerFQCN = SLF4JImpl.class.getName();
	private static final Logger testLogger = LoggerFactory.getLogger(SLF4JImpl.class);
	private int errorCount;
	private int warnCount;
	private int infoCount;
	private int debugCount;
	private LocationAwareLogger log;

	public SLF4JImpl(LocationAwareLogger log) {
		this.log = log;
	}

	public SLF4JImpl(String loggerName) {
		this.log = ((LocationAwareLogger) LoggerFactory.getLogger(loggerName));
	}

	public boolean isDebugEnabled() {
		return this.log.isDebugEnabled();
	}

	public void error(String msg, Throwable e) {
		this.log.log(null, callerFQCN, LocationAwareLogger.ERROR_INT, msg, null, e);
		this.errorCount += 1;
	}

	public void error(String msg) {
		this.log.log(null, callerFQCN, LocationAwareLogger.ERROR_INT, msg, null, null);
		this.errorCount += 1;
	}

	public boolean isInfoEnabled() {
		return this.log.isInfoEnabled();
	}

	public void info(String msg) {
		this.infoCount += 1;
		this.log.log(null, callerFQCN, LocationAwareLogger.INFO_INT, msg, null, null);
	}

	public void debug(String msg) {
		this.debugCount += 1;
		this.log.log(null, callerFQCN, LocationAwareLogger.DEBUG_INT, msg, null, null);
	}

	public void debug(String msg, Throwable e) {
		this.debugCount += 1;
		this.log.log(null, callerFQCN, LocationAwareLogger.DEBUG_INT, msg, null, e);
	}

	public boolean isWarnEnabled() {
		return this.log.isWarnEnabled();
	}

	public void warn(String msg) {
		this.log.log(null, callerFQCN, LocationAwareLogger.WARN_INT, msg, null, null);
		this.warnCount += 1;
	}

	public void warn(String msg, Throwable e) {
		this.log.log(null, callerFQCN, LocationAwareLogger.WARN_INT, msg, null, e);
		this.warnCount += 1;
	}

	public int getErrorCount() {
		return this.errorCount;
	}

	public int getWarnCount() {
		return this.warnCount;
	}

	public int getInfoCount() {
		return this.infoCount;
	}

	public int getDebugCount() {
		return this.debugCount;
	}

	public void resetStat() {
		this.errorCount = 0;
		this.warnCount = 0;
		this.infoCount = 0;
		this.debugCount = 0;
	}

	static {
		if (!(testLogger instanceof LocationAwareLogger))
			throw new UnsupportedOperationException(testLogger.getClass() + " is not a suitable logger");
	}

}

package com.cjhxfund.foundation.log.impl;

import java.lang.reflect.Constructor;

public class LogFactory {

	private static Constructor logConstructor;

	private static void tryImplementation(String testClassName, String implClassName) {
		if (logConstructor != null) {
			return;
		}
		try {
			Resources.classForName(testClassName);
			Class implClass = Resources.classForName(implClassName);
			logConstructor = implClass.getConstructor(new Class[] { String.class });

			Class declareClass = logConstructor.getDeclaringClass();
			if (!Log.class.isAssignableFrom(declareClass)) {
				logConstructor = null;
			}
			try {
				if (null != logConstructor)
					logConstructor.newInstance(new Object[] { LogFactory.class.getName() });
			} catch (Throwable t) {
				logConstructor = null;
			}
		} catch (Throwable t) {
		}
	}

	public static Log getLog(Class clazz) {
		return getLog(clazz.getName());
	}

	public static Log getLog(String loggerName) {
		try {
			return (Log) logConstructor.newInstance(new Object[] { loggerName });
		} catch (Throwable t) {
			throw new RuntimeException("Error creating logger for logger '" + loggerName + "'.  Cause: " + t, t);
		}
	}

	public static synchronized void selectLog4JLogging() {
		try {
			Resources.classForName("org.apache.log4j.Logger");
			Class implClass = Resources.classForName("com.cjhxfund.foundation.log.impl.Log4jImpl");
			logConstructor = implClass.getConstructor(new Class[] { String.class });
		} catch (Throwable t) {
		}
	}

	public static synchronized void selectJavaLogging() {
		try {
			Resources.classForName("java.util.logging.Logger");
			Class implClass = Resources.classForName("com.cjhxfund.foundation.log.impl.Jdk14LoggingImpl");
			logConstructor = implClass.getConstructor(new Class[] { String.class });
		} catch (Throwable t) {
		}
	}

	static {
		tryImplementation("org.apache.log4j.Logger", "com.cjhxfund.foundation.log.impl.Log4jImpl");
		tryImplementation("org.slf4j.Logger", "com.cjhxfund.foundation.log.impl.SLF4JImpl");
		tryImplementation("org.apache.commons.logging.LogFactory", "com.cjhxfund.foundation.log.impl.CommonsLoggingImpl");

		tryImplementation("java.util.logging.Logger", "com.cjhxfund.foundation.log.impl.Jdk14LoggingImpl");

		if (logConstructor == null)
			try {
				logConstructor = NoLoggingImpl.class.getConstructor(new Class[] { String.class });
			} catch (Exception e) {
				throw new IllegalStateException(e.getMessage(), e);
			}
	}
}

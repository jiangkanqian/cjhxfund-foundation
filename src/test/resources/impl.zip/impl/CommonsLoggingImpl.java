package com.cjhxfund.foundation.log.impl;

public class CommonsLoggingImpl  implements Log{

	 private org.apache.commons.logging.Log log;
	  private int errorCount;
	  private int warnCount;
	  private int infoCount;
	  private int debugCount;

	  public CommonsLoggingImpl(org.apache.commons.logging.Log log)
	  {
	    this.log = log;
	  }

	  public CommonsLoggingImpl(String loggerName) {
	    this.log = (org.apache.commons.logging.Log) LogFactory.getLog(loggerName);
	  }

	  public boolean isDebugEnabled() {
	    return this.log.isDebugEnabled();
	  }

	  public void error(String s, Throwable e) {
	    this.log.error(s, e);
	    this.errorCount += 1;
	  }

	  public void error(String s) {
	    this.log.error(s);
	    this.errorCount += 1;
	  }

	  public void debug(String s) {
	    this.debugCount += 1;
	    this.log.debug(s);
	  }

	  public void debug(String s, Throwable e) {
	    this.debugCount += 1;
	    this.log.debug(s, e);
	  }

	  public void warn(String s) {
	    this.log.warn(s);
	    this.warnCount += 1;
	  }

	  public void warn(String s, Throwable e)
	  {
	    this.log.warn(s, e);
	    this.warnCount += 1;
	  }

	  public int getWarnCount()
	  {
	    return this.warnCount;
	  }

	  public int getErrorCount() {
	    return this.errorCount;
	  }

	  public void resetStat()
	  {
	    this.errorCount = 0;
	    this.warnCount = 0;
	    this.infoCount = 0;
	    this.debugCount += 1;
	  }

	  public boolean isInfoEnabled()
	  {
	    return this.log.isInfoEnabled();
	  }

	  public void info(String msg)
	  {
	    this.log.info(msg);
	    this.infoCount += 1;
	  }

	  public int getInfoCount()
	  {
	    return this.infoCount;
	  }

	  public boolean isWarnEnabled()
	  {
	    return this.log.isWarnEnabled();
	  }

	  public int getDebugCount() {
	    return this.debugCount;
	  }
}
